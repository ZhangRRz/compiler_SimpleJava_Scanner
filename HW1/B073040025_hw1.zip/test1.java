
public class Test1 {
    public static int add(int a, int b) {
        return a + b;
    }

    public static void main() {

        int c;
        int a = 5;
        c = add(a, 10);
        if (c > 10)
            print("c = " + -c);
        else
            print(c);
        print("Hello World");

    }

}

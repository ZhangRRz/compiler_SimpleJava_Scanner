int 555aiii
int 3aaa
int a
float asdasd

asdasd = 5;
3aaaa = 5;
a = 4;
^kbbbbbs6666
#_qweqweqe
#5566asdasdx

"wts\"ertg\"ertgerg"

"qw\\eqweqeq\"eqe"weqwefqfqf"

"qweqweqweqeqweqweqwe

awdawdawdawdawdawdawd

'a----------wdwadad'
"kjlkjlkjkllkj-----------------------

"\"